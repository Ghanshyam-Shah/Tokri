import React, { useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  Animated,
  Platform,
} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from '../../../app/providers/ThemeProvider';

interface AppHeaderProps {
  title?: string;
  leftIcon: React.ComponentProps<typeof Icon>['name'];
  onLeftPress: () => void;
}

const HEADER_HEIGHT = Platform.OS === 'ios' ? 48 : 54;
const H_PADDING = 16;

const AppHeader: React.FC<AppHeaderProps> = ({
  title = 'KiranaList',
  leftIcon,
  onLeftPress,
}) => {
  const { theme, isDark, toggleTheme } = useTheme();

  const { colors, borderRadius, shadows, fontFamilies, typography } = theme;

  const leftAnim = useRef(new Animated.Value(1)).current;
  const themeAnim = useRef(new Animated.Value(1)).current;

  const springPress = (anim: Animated.Value) => {
    Animated.sequence([
      Animated.spring(anim, {
        toValue: 0.78,
        useNativeDriver: true,
        speed: 60,
        bounciness: 4,
      }),
      Animated.spring(anim, {
        toValue: 1,
        useNativeDriver: true,
        speed: 25,
        bounciness: 10,
      }),
    ]).start();
  };

  const handleLeftPress = () => {
    springPress(leftAnim);
    onLeftPress();
  };

  const handleTheme = () => {
    springPress(themeAnim);
    toggleTheme();
  };

  return (
    <>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.appBackground}
        translucent={false}
      />

      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.appBackground,
            ...shadows.sm,
          },
        ]}
      >
        {/* Left Icon */}
        <Animated.View
          style={{
            transform: [{ scale: leftAnim }],
          }}
        >
          <TouchableOpacity
            onPress={handleLeftPress}
            activeOpacity={0.75}
            hitSlop={{
              top: 10,
              bottom: 10,
              left: 10,
              right: 10,
            }}
            style={[
              styles.iconButton,
              {
                borderRadius: borderRadius.sm,
              },
            ]}
          >
            <Icon name={leftIcon} size={28} color={colors.headerContent} />
          </TouchableOpacity>
        </Animated.View>

        {/* Title */}
        <Text
          numberOfLines={1}
          style={[
            styles.title,
            {
              color: colors.headerContent,
              fontFamily: fontFamilies.bold,
              fontSize: typography.lg,
              letterSpacing: 0.3,
            },
          ]}
        >
          {title}
        </Text>

        {/* Theme Toggle */}
        <Animated.View
          style={{
            transform: [{ scale: themeAnim }],
          }}
        >
          <TouchableOpacity
            onPress={handleTheme}
            activeOpacity={0.75}
            hitSlop={{
              top: 10,
              bottom: 10,
              left: 10,
              right: 10,
            }}
            style={[
              styles.iconButton,
              {
                borderRadius: borderRadius.sm,
              },
            ]}
          >
            <Icon
              name={isDark ? 'white-balance-sunny' : 'weather-night'}
              size={22}
              color={isDark ? '#FCD34D' : '#818CF8'}
            />
          </TouchableOpacity>
        </Animated.View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    height: HEADER_HEIGHT,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: H_PADDING,
  },

  iconButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },

  title: {
    flex: 1,
    textAlign: 'center',
    fontWeight: '700',
  },
});

export default React.memo(AppHeader);
