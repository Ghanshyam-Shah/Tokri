// src/theme/colors.ts
// Design system se liye gaye exact color tokens
// Light  → "Kitchen Notebook Modern"
// Dark   → "KiranaList Dark Mode"

export const lightColors = {
  appBackground: '#fcf9f4',
  headerBackground: '#fcf9f4',
  headerContent: '#9d4300',
};

export const darkColors = {
  appBackground: '#1c110b',
  headerBackground: '#1c110b',
  headerContent: '#ffb690',
};
