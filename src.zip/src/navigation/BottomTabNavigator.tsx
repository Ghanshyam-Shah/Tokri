// import React from 'react';
// import { View, TouchableOpacity, StyleSheet } from 'react-native';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Ionicons from 'react-native-vector-icons/Ionicons';
// // import Feather from 'react-native-vector-icons/Feather';
// import HomeStackNavigator from './stacks/HomeStackNavigator';
// import ListStackNavigator from './stacks/ListStackNavigator';
// import HistoryStackNavigator from './stacks/HistoryStackNavigator';
// import CatalogStackNavigator from './stacks/CatalogStackNavigator';
// import { BottomTabParamList } from './types/navigationTypes';
// import CreateStackNavigator from './stacks/CreateStackNavigator';

// const Tab = createBottomTabNavigator<BottomTabParamList>();

// const CustomAddButton = ({ onPress }: any) => {
//   return (
//     <TouchableOpacity
//       activeOpacity={0.8}
//       onPress={onPress}
//       style={styles.addButtonContainer}
//     >
//       <View style={styles.addButton}>
//         <Ionicons name="add" size={30} color="#fff" />
//       </View>
//     </TouchableOpacity>
//   );
// };

// export default function BottomTabs() {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         headerShown: false,

//         tabBarShowLabel: true,

//         tabBarActiveTintColor: '#1c110b',
//         tabBarInactiveTintColor: '#9CA3AF',

//         tabBarStyle: {
//           // height: 80,
//           height: 60,
//           backgroundColor: '#ffffff',
//           borderTopWidth: 0,
//           elevation: 10,
//           shadowColor: '#000',
//           shadowOpacity: 0.06,
//           shadowRadius: 10,
//           shadowOffset: {
//             width: 0,
//             height: -3,
//           },
//           // paddingBottom: 10,
//           // paddingTop: 10,
//         },

//         tabBarLabelStyle: {
//           fontSize: 12,
//           fontWeight: '600',
//           // marginTop: 4,
//           marginTop: 0,
//         },

//         tabBarIcon: ({ focused, color, size }) => {
//           let iconName:
//             | 'home'
//             | 'home-outline'
//             | 'receipt'
//             | 'receipt-outline'
//             | 'grid'
//             | 'grid-outline'
//             | 'time'
//             | 'time-outline'
//             | 'ellipse' = 'home';

//           switch (route.name) {
//             case 'HomeTab':
//               iconName = focused ? 'home' : 'home-outline';
//               break;

//             case 'ListTab':
//               iconName = focused ? 'receipt' : 'receipt-outline';
//               break;

//             case 'CatalogTab':
//               iconName = focused ? 'grid' : 'grid-outline';
//               break;

//             case 'HistoryTab':
//               iconName = focused ? 'time' : 'time-outline';
//               break;

//             default:
//               iconName = 'ellipse';
//           }

//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//       })}
//     >
//       <Tab.Screen
//         name="HomeTab"
//         component={HomeStackNavigator}
//         options={{
//           tabBarLabel: 'Home',
//         }}
//       />

//       <Tab.Screen
//         name="ListTab"
//         component={ListStackNavigator}
//         options={{
//           tabBarLabel: 'List',
//         }}
//       />

//       <Tab.Screen
//         name="CreateTab"
//         component={CreateStackNavigator}
//         options={{
//           tabBarLabel: '',
//           tabBarIcon: () => null,
//           tabBarButton: props => <CustomAddButton {...props} />,
//         }}
//       />

//       <Tab.Screen
//         name="CatalogTab"
//         component={CatalogStackNavigator}
//         options={{
//           tabBarLabel: 'Catalog',
//         }}
//       />

//       <Tab.Screen
//         name="HistoryTab"
//         component={HistoryStackNavigator}
//         options={{
//           tabBarLabel: 'History',
//         }}
//       />
//     </Tab.Navigator>
//   );
// }

// const styles = StyleSheet.create({
//   addButtonContainer: {
//     // top: -20,
//     top: -10,

//     justifyContent: 'center',
//     alignItems: 'center',
//   },

//   addButton: {
//     width: 62,
//     height: 62,
//     borderRadius: 31,
//     borderWidth: 4,
//     borderColor: '#ffffff',
//     // backgroundColor: '#1F6E43',
//     backgroundColor: '#1c110b',

//     justifyContent: 'center',
//     alignItems: 'center',

//     // shadowColor: '#1F6E43',
//     shadowColor: '#1c110b',

//     shadowOpacity: 0.3,
//     shadowRadius: 10,
//     shadowOffset: {
//       width: 0,
//       height: 5,
//     },

//     elevation: 8,
//   },
// });

// src/navigation/BottomTabNavigator.tsx

import React from 'react';
import { View, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

import HomeStackNavigator from './stacks/HomeStackNavigator';
import ListStackNavigator from './stacks/ListStackNavigator';
import CatalogStackNavigator from './stacks/CatalogStackNavigator';
import HistoryStackNavigator from './stacks/HistoryStackNavigator';
import CreateStackNavigator from './stacks/CreateStackNavigator';

import { BottomTabParamList } from './types/navigationTypes';

// ─── Same DARK palette as CatalogScreen / NewListScreen ──────────────────────
const DARK = {
  bg: '#1c110b',
  surface: '#251913',
  border: '#3a2418',
  primary: '#f97316',
  textPrimary: '#f6ded3',
  textMuted: '#a78b7d',
};

const Tab = createBottomTabNavigator<BottomTabParamList>();

// ─── Center FAB button ────────────────────────────────────────────────────────
const CustomAddButton = ({ onPress }: any) => (
  <TouchableOpacity
    activeOpacity={0.8}
    onPress={onPress}
    style={styles.fabWrap}
  >
    <View style={styles.fab}>
      <Ionicons name="add" size={28} color="#fff" />
    </View>
  </TouchableOpacity>
);

// ─── Navigator ────────────────────────────────────────────────────────────────
export default function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: true,

        tabBarActiveTintColor: DARK.primary,
        tabBarInactiveTintColor: DARK.textMuted,

        tabBarStyle: {
          height: Platform.OS === 'ios' ? 60 : 58,
          backgroundColor: DARK.surface,
          borderTopWidth: 1,
          borderTopColor: DARK.border,
          elevation: 12,
          shadowColor: '#000',
          shadowOpacity: 0.3,
          shadowRadius: 8,
          shadowOffset: { width: 0, height: -2 },
          paddingTop: 4,
          paddingBottom: Platform.OS === 'ios' ? 8 : 6,
        },

        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
          marginTop: 1,
        },

        tabBarIcon: ({ focused, color }) => {
          type IoniconsName =
            | 'home'
            | 'home-outline'
            | 'receipt'
            | 'receipt-outline'
            | 'grid'
            | 'grid-outline'
            | 'time'
            | 'time-outline'
            | 'ellipse';

          let iconName: IoniconsName = 'ellipse';

          switch (route.name) {
            case 'HomeTab':
              iconName = focused ? 'home' : 'home-outline';
              break;
            case 'ListTab':
              iconName = focused ? 'receipt' : 'receipt-outline';
              break;
            case 'CatalogTab':
              iconName = focused ? 'grid' : 'grid-outline';
              break;
            case 'HistoryTab':
              iconName = focused ? 'time' : 'time-outline';
              break;
          }

          return <Ionicons name={iconName} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStackNavigator}
        options={{ tabBarLabel: 'Home' }}
      />

      <Tab.Screen
        name="ListTab"
        component={ListStackNavigator}
        options={{ tabBarLabel: 'List' }}
      />

      <Tab.Screen
        name="CreateTab"
        component={CreateStackNavigator}
        options={{
          tabBarLabel: '',
          tabBarIcon: () => null,
          tabBarButton: props => <CustomAddButton {...props} />,
        }}
      />

      <Tab.Screen
        name="CatalogTab"
        component={CatalogStackNavigator}
        options={{ tabBarLabel: 'Catalog' }}
      />

      <Tab.Screen
        name="HistoryTab"
        component={HistoryStackNavigator}
        options={{ tabBarLabel: 'History' }}
      />
    </Tab.Navigator>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  fabWrap: {
    top: -16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fab: {
    width: 54,
    height: 54,
    borderRadius: 27,
    borderWidth: 3,
    borderColor: DARK.surface,
    backgroundColor: DARK.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: DARK.primary,
    shadowOpacity: 0.45,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
});
