import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Ionicons from 'react-native-vector-icons/Ionicons';

import CatalogStackNavigator from './stacks/CatalogStackNavigator';
import HistoryStackNavigator from './stacks/HistoryStackNavigator';
import HomeStackNavigator from './stacks/HomeStackNavigator';
import ListStackNavigator from './stacks/ListStackNavigator';

import { BottomTabParamList } from './types/navigationTypes';

const Tab = createBottomTabNavigator<BottomTabParamList>();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,

        tabBarActiveTintColor: '#6C63FF',
        tabBarInactiveTintColor: '#999999',

        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#f0f0f0',
          height: 60,
          paddingBottom: 5,
          paddingTop: 5,
        },

        tabBarLabelStyle: {
          fontSize: 12,
        },

      tabBarIcon: ({ focused, color, size }) => {
  let iconName:
    | 'home'
    | 'home-outline'
    | 'grid'
    | 'grid-outline'
    | 'cart'
    | 'cart-outline'
    | 'list'
    | 'list-outline'
    | 'ellipse' = 'home';

  switch (route.name) {
    case 'HomeTab':
      iconName = focused ? 'home' : 'home-outline';
      break;

    case 'ListTab':
      iconName = focused ? 'grid' : 'grid-outline';
      break;

    case 'CatalogTab':
      iconName = focused ? 'cart' : 'cart-outline';
      break;

    case 'HistoryTab':
      iconName = focused ? 'list' : 'list-outline';
      break;

    default:
      iconName = 'ellipse';
  }

  return (
    <Ionicons
      name={iconName}
      size={size ?? 24}
      color={color}
    />
  );
},
      })}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStackNavigator}
        options={{
          tabBarLabel: 'Home',
        }}
      />

      <Tab.Screen
        name="ListTab"
        component={ListStackNavigator}
        options={{
          tabBarLabel: 'List',
        }}
      />

      <Tab.Screen
        name="CatalogTab"
        component={CatalogStackNavigator}
        options={{
          tabBarLabel: 'Catalog',
        }}
      />

      <Tab.Screen
        name="HistoryTab"
        component={HistoryStackNavigator}
        options={{
          tabBarLabel: 'History',
        }}
      />
    </Tab.Navigator>
  );
};

export default BottomTabNavigator;