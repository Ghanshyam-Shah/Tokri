// src/features/list/screens/CreateListScreen.tsx

import React from 'react';

import { View, Text, StyleSheet, StatusBar } from 'react-native';

import { RouteProp, useRoute } from '@react-navigation/native';

import { CreateStackParamList } from '../../../navigation/types/navigationTypes';

type RouteProps = RouteProp<CreateStackParamList, 'CreateListScreen'>;

const CreateListScreen = () => {
  const route = useRoute<RouteProps>();

  const listId = route.params?.listId;

  return (
    <View style={styles.main}>
      <StatusBar barStyle="light-content" backgroundColor="dark-content" />
      <Text style={styles.text}>CreateListScreen</Text>

      <Text style={styles.text}>List ID: {listId}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  text: {
    fontSize: 18,
    marginBottom: 10,
  },
});

export default CreateListScreen;
