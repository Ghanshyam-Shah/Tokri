import { View, Text } from 'react-native';
import React from 'react';

const ListScreen = () => {
  return (
    <View>
      <Text>HomeScreen</Text>
    </View>
  );
};

export default ListScreen;
